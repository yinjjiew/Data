# This is the majority-optimal workflow structure for question-answering tasks.

async def run_workflow(self):
    """
    This is a workflow graph.
    """
    
    solution = await self.answer_generate()
    
    solution = await self.review(solution)
    
    solution_list = [solution]
    
    for _ in range(3):
        solution = await self.custom_2(instruction="Can you solve this problem by breaking it down into detailed steps and explaining the reasoning behind each step?")
        solution_list.append(solution)
    
    ensembled_solution = await self.sc_ensemble(solution_list)
    
    return ensembled_solution

#The answer extractor operator (./ScoreFlow/scripts/task/extraction.py) is added after the final output of every workflow. Since it only appears at the end of each workflow, it does not influence its structure.