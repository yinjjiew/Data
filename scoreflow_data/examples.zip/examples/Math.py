# This is the majority-optimal workflow structure for math tasks.

async def run_workflow(self):
    """
    This is a workflow graph.
    """
    
    solution_1 = await self.custom_1(instruction =" Can you break down the problem into smaller steps ?")
    
    solution_2 = await self.custom_2(instruction =" Can you explain the solution in a clear and concise manner ?")
    
    analysis = solution_1 + solution_2
    
    program_solution = await self.programmer(analysis = analysis)
    
    solutions = [solution_1 , solution_2 , program_solution]
    
    ensembled_solution = await self.sc_ensemble(solutions = solutions)
    
    final_solution = await self.review(pre_solution = ensembled_solution)
    
    return final_solution

#The answer extractor operator (./ScoreFlow/scripts/task/extraction.py) is added after the final output of every workflow. Since it only appears at the end of each workflow, it does not influence its structure.